package me.kamu.tycoon;

import org.bukkit.block.Block;
import org.bukkit.scheduler.BukkitRunnable;

public class GeneratorTask extends BukkitRunnable {

    @Override
    public void run() {
        GeneratorManager.getGenerators().forEach((loc, data) -> {
            Block block = loc.getBlock();

            // update block sesuai level
            block.setType(GeneratorManager.getMaterialByLevel(data.level));

            // deposit uang ke player di radius 5
            loc.getWorld().getPlayers().forEach(p -> {
                if (p.getLocation().distance(loc) < 5) {
                    double money = data.level * 10;
                    VaultHook.get().depositPlayer(p, money);
                    p.sendActionBar("§a+$" + money + " dari generator");
                }
            });
        });
    }
}
