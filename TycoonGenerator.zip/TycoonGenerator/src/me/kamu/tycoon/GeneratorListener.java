package me.kamu.tycoon;

import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.player.PlayerInteractEvent;

public class GeneratorListener implements Listener {

    @EventHandler
    public void onPlace(BlockPlaceEvent e) {
        if (e.getItemInHand().getType() == Material.DIAMOND_BLOCK) {
            Location loc = e.getBlock().getLocation();
            Player p = e.getPlayer();

            GeneratorManager.saveGenerator(loc, p.getUniqueId());
            p.sendMessage("§aGenerator dipasang!");
        }
    }

    @EventHandler
    public void onInteract(PlayerInteractEvent e) {
        if (e.getClickedBlock() == null) return;

        if (e.getClickedBlock().getType() != Material.DIAMOND_BLOCK) return;

        Location loc = e.getClickedBlock().getLocation();
        GeneratorManager.GeneratorData data = GeneratorManager.get(loc);
        Player p = e.getPlayer();

        if (data == null) return;

        if (!data.owner.equals(p.getUniqueId())) {
            p.sendMessage("§cIni bukan generatormu!");
            return;
        }

        e.setCancelled(true);
        GeneratorGUI.open(p, loc);
    }
}
