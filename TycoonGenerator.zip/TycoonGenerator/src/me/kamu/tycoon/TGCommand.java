package me.kamu.tycoon;

import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class TGCommand implements CommandExecutor {

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {

        if (!(sender instanceof Player)) {
            sender.sendMessage("Hanya player yang bisa menjalankan command ini!");
            return true;
        }

        Player executor = (Player) sender;

        if (!executor.isOp()) {
            executor.sendMessage("§cHanya operator yang bisa menggunakan command ini!");
            return true;
        }

        Player target;
        int level = 1; // default level pertama

        if (args.length == 0) {
            target = executor;
        } else {
            target = Bukkit.getPlayer(args[0]);
            if (target == null) {
                executor.sendMessage("§cPlayer tidak ditemukan!");
                return true;
            }

            if (args.length >= 2) {
                try {
                    level = Integer.parseInt(args[1]);
                } catch (NumberFormatException e) {
                    executor.sendMessage("§cLevel harus berupa angka!");
                    return true;
                }
            }
        }

        // cek level valid
        if (level < 1) level = 1;
        if (level > 7) level = 7;

        // kasih item generator (Diamond Block)
        target.getInventory().addItem(new org.bukkit.inventory.ItemStack(Material.DIAMOND_BLOCK, 1));

        // save generator level di cache GeneratorManager jika mau
        // bisa juga nanti pas ditempatkan, level akan otomatis 1–7

        target.sendMessage("§aKamu menerima generator level " + level + "!");
        if (!target.equals(executor)) {
            executor.sendMessage("§aGenerator level " + level + " berhasil diberikan ke " + target.getName() + "!");
        }

        return true;
    }
}
