package me.kamu.tycoon;

import org.bukkit.Bukkit;
import org.bukkit.plugin.java.JavaPlugin;

public class Main extends JavaPlugin {

    public static Main instance;

    @Override
    public void onEnable() {
        instance = this;

        if (!VaultHook.setup()) {
            getLogger().severe("Vault tidak ditemukan! Plugin dinonaktifkan.");
            getServer().getPluginManager().disablePlugin(this);
            return;
        }

        getLogger().info("Vault terhubung!");

        // register listener & GUI
        Bukkit.getPluginManager().registerEvents(new GeneratorListener(), this);
        Bukkit.getPluginManager().registerEvents(new GeneratorGUI(), this);

        // jalankan scheduler income
        new GeneratorTask().runTaskTimer(this, 20L, 20L);

        getLogger().info("TycoonGenerator aktif!");
    }
    
    this.getCommand("tg").setExecutor(new TGCommand());

    public static Main getInstance() {
        return instance;
    }
}
