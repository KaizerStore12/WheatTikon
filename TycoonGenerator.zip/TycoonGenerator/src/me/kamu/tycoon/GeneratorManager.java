package me.kamu.tycoon;

import org.bukkit.Location;
import org.bukkit.Material;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class GeneratorManager {

    public static class GeneratorData {
        public int level;
        public UUID owner;

        public GeneratorData(int level, UUID owner) {
            this.level = level;
            this.owner = owner;
        }
    }

    private static final Map<Location, GeneratorData> generators = new HashMap<>();

    private static final Material[] UPGRADE_MATERIALS = {
            Material.DIRT,
            Material.STONE,
            Material.COAL_ORE,
            Material.COPPER_ORE,
            Material.DIAMOND_ORE,
            Material.EMERALD_ORE,
            Material.NETHERITE_BLOCK
    };

    public static void saveGenerator(Location loc, UUID owner) {
        generators.put(loc, new GeneratorData(1, owner));
    }

    public static GeneratorData get(Location loc) {
        return generators.get(loc);
    }

    public static Map<Location, GeneratorData> getGenerators() {
        return generators;
    }

    public static void upgradeNearest(Location loc) {
        generators.forEach((genLoc, data) -> {
            if (genLoc.getWorld().equals(loc.getWorld()) &&
                genLoc.distance(loc) < 3) {
                data.level++;
            }
        });
    }

    public static Material getMaterialByLevel(int level) {
        if (level <= 0) return Material.DIRT;
        if (level > UPGRADE_MATERIALS.length)
            return UPGRADE_MATERIALS[UPGRADE_MATERIALS.length - 1];
        return UPGRADE_MATERIALS[level - 1];
    }
}
