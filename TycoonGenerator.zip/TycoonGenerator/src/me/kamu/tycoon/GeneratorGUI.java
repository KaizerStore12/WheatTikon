package me.kamu.tycoon;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class GeneratorGUI implements Listener {

    private static final Map<UUID, Location> cache = new HashMap<>();

    public static void open(Player p, Location loc) {
        Inventory inv = Bukkit.createInventory(null, 27, "§6Generator");

        GeneratorManager.GeneratorData data = GeneratorManager.get(loc);

        // info block
        ItemStack info = new ItemStack(Material.PAPER);
        ItemMeta meta = info.getItemMeta();
        meta.setDisplayName("§eLevel: §a" + data.level);
        meta.setLore(java.util.List.of(
                "§7Block saat ini: §f" + GeneratorManager.getMaterialByLevel(data.level).name(),
                "§7Income per tick: §a$" + (data.level * 10),
                "§7Owner: §f" + p.getName()
        ));
        info.setItemMeta(meta);

        // upgrade
        ItemStack upgrade = new ItemStack(Material.EMERALD_BLOCK);
        ItemMeta u = upgrade.getItemMeta();
        u.setDisplayName("§aUpgrade Generator");
        u.setLore(java.util.List.of("§7Harga: §e$" + (data.level * 100)));
        upgrade.setItemMeta(u);

        // sell
        ItemStack sell = new ItemStack(Material.GOLD_INGOT);
        ItemMeta s = sell.getItemMeta();
        s.setDisplayName("§6Sell Hasil Generator");
        sell.setItemMeta(s);

        inv.setItem(11, upgrade);
        inv.setItem(13, info);
        inv.setItem(15, sell);

        p.openInventory(inv);
        cache.put(p.getUniqueId(), loc);
    }

    @EventHandler
    public void onClick(InventoryClickEvent e) {
        if (!e.getView().getTitle().equals("§6Generator")) return;

        e.setCancelled(true);
        Player p = (Player) e.getWhoClicked();
        UUID uuid = p.getUniqueId();
        Location loc = cache.get(uuid);

        if (loc == null) return;

        GeneratorManager.GeneratorData data = GeneratorManager.get(loc);
        if (data == null) return;

        if (e.getCurrentItem() == null) return;

        switch (e.getCurrentItem().getType()) {
            case EMERALD_BLOCK -> {
                double price = data.level * 100;
                if (!VaultHook.get().has(p, price)) {
                    p.sendMessage("§cUang tidak cukup!");
                    return;
                }

                VaultHook.get().withdrawPlayer(p, price);
                data.level++;
                GeneratorManager.upgradeNearest(loc);
                p.sendMessage("§aGenerator berhasil di-upgrade!");
                open(p, loc); // refresh GUI
            }
            case GOLD_INGOT -> {
                double sell = data.level * 50;
                VaultHook.get().depositPlayer(p, sell);
                p.sendMessage("§6+$" + sell + " hasil generator");
            }
        }
    }
}
