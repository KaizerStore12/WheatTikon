package me.wheatycoon.listener;

import me.wheatycoon.WheatTycoon;
import me.wheatycoon.gui.TycoonGUI;
import me.wheatycoon.tycoon.Tycoon;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.block.Action;

public class TycoonInteractListener implements Listener {

    private final WheatTycoon plugin;

    public TycoonInteractListener(WheatTycoon plugin) {
        this.plugin = plugin;
    }

    @EventHandler
    public void onInteract(PlayerInteractEvent e) {
        if (e.getAction() != Action.RIGHT_CLICK_BLOCK) return;
        if (e.getClickedBlock() == null) return;

        String key = e.getClickedBlock().getLocation().toString();
        Tycoon tycoon = plugin.getTycoonManager().getTycoon(key);

        if (tycoon == null) return;

        e.setCancelled(true);
        TycoonGUI.open(e.getPlayer(), tycoon);
    }
}
