package me.wheatycoon.listener;

import me.wheatycoon.WheatTycoon;
import me.wheatycoon.tycoon.Tycoon;
import me.wheatycoon.util.VaultUtil;
import net.milkbowl.vault.economy.Economy;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.ItemStack;

public class TycoonGUIListener implements Listener {

    private final WheatTycoon plugin;
    private final Economy econ;

    public TycoonGUIListener(WheatTycoon plugin) {
        this.plugin = plugin;
        this.econ = VaultUtil.getEconomy();
    }

    @EventHandler
    public void onClick(InventoryClickEvent e) {
        if (!e.getView().getTitle().equals("§eWheat Tycoon")) return;
        e.setCancelled(true);

        if (!(e.getWhoClicked() instanceof Player p)) return;
        ItemStack item = e.getCurrentItem();
        if (item == null) return;

        Tycoon tycoon = plugin.getTycoonManager()
                .getTycoon(p.getTargetBlockExact(5).getLocation().toString());

        if (tycoon == null) return;

        switch (item.getType()) {

            // 🌾 COLLECT
            case WHEAT -> {
                int amount = tycoon.getStoredWheat();
                if (amount <= 0) {
                    p.sendMessage("§cTidak ada wheat!");
                    return;
                }
                p.getInventory().addItem(new ItemStack(Material.WHEAT, amount));
                tycoon.clearWheat();
                p.sendMessage("§aCollect " + amount + " wheat");
            }

            // 💰 AUTO SELL
            case GOLD_INGOT -> {
                int amount = tycoon.getStoredWheat();
                if (amount <= 0) return;

                double price = plugin.getConfig().getDouble("sell-price");
                econ.depositPlayer(p, amount * price);
                tycoon.clearWheat();

                p.sendMessage("§6Auto-Sell: +" + (amount * price));
            }

            // ⬆️ UPGRADE
            case ANVIL -> {
                int next = tycoon.getLevel() + 1;
                if (!plugin.getConfig().contains("levels." + next)) {
                    p.sendMessage("§cLevel maksimal!");
                    return;
                }

                double cost = plugin.getConfig()
                        .getDouble("levels." + next + ".upgrade-cost");

                if (!econ.has(p, cost)) {
                    p.sendMessage("§cUang tidak cukup!");
                    return;
                }

                econ.withdrawPlayer(p, cost);
                tycoon.upgrade();
                p.sendMessage("§bTycoon upgrade ke level " + next);
            }
        }
    }
}
