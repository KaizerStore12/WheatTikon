package me.wheatycoon.listener;

import me.wheatycoon.WheatTycoon;
import me.wheatycoon.tycoon.Tycoon;
import org.bukkit.Material;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.entity.Player;

public class TycoonPlaceListener implements Listener {

    private final WheatTycoon plugin;

    public TycoonPlaceListener(WheatTycoon plugin) {
        this.plugin = plugin;
    }

    @EventHandler
    public void onPlace(BlockPlaceEvent e) {
        if (e.getBlockPlaced().getType() != Material.HAY_BLOCK) return;

        Player p = e.getPlayer();

        String key = e.getBlockPlaced().getLocation().toString();
        Tycoon tycoon = new Tycoon(p.getUniqueId(), e.getBlockPlaced().getLocation());

        plugin.getTycoonManager().addTycoon(key, tycoon);
        p.sendMessage("§aWheat Tycoon dipasang!");
    }
}
