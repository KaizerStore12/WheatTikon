package me.wheatycoon.tycoon;

import me.wheatycoon.WheatTycoon;
import org.bukkit.scheduler.BukkitRunnable;

import java.util.HashMap;
import java.util.Map;

public class TycoonManager {

    private final WheatTycoon plugin;
    private final Map<String, Tycoon> tycoons = new HashMap<>();

    public TycoonManager(WheatTycoon plugin) {
        this.plugin = plugin;
    }

    // Key string biar simpel di STEP 1
    public void addTycoon(String key, Tycoon tycoon) {
        tycoons.put(key, tycoon);
    }

    public Tycoon getTycoon(String key) {
        return tycoons.get(key);
    }

    public Map<String, Tycoon> getAll() {
        return tycoons;
    }

    // Generator global (TPS friendly)
    public void startGenerator() {
        new BukkitRunnable() {
            @Override
            public void run() {
                for (Tycoon t : tycoons.values()) {
                    int lvl = t.getLevel();
                    int produce = plugin.getConfig().getInt("levels." + lvl + ".produce");
                    int max = plugin.getConfig().getInt("levels." + lvl + ".storage");
                    t.addWheat(produce, max);
                }
            }
        }.runTaskTimer(plugin, 0L, 100L); // 5 detik
    }
}
