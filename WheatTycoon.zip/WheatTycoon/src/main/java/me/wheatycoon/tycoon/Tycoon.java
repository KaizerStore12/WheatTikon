package me.wheatycoon.tycoon;

import org.bukkit.Location;

import java.util.UUID;

public class Tycoon {

    private final UUID owner;
    private final Location location;

    private int level;
    private int storedWheat;

    public Tycoon(UUID owner, Location location) {
        this.owner = owner;
        this.location = location;
        this.level = 1;
        this.storedWheat = 0;
    }

    public UUID getOwner() {
        return owner;
    }

    public Location getLocation() {
        return location;
    }

    public int getLevel() {
        return level;
    }

    public int getStoredWheat() {
        return storedWheat;
    }

    public void addWheat(int amount, int maxStorage) {
        storedWheat = Math.min(storedWheat + amount, maxStorage);
    }

    public void clearWheat() {
        storedWheat = 0;
    }

    public void upgrade() {
        level++;
    }
}
