package me.wheatycoon;

import me.wheatycoon.listener.TycoonInteractListener;
import me.wheatycoon.listener.TycoonGUIListener;
import me.wheatycoon.util.VaultUtil;
import me.wheatycoon.listener.TycoonPlaceListener;
import me.wheatycoon.tycoon.TycoonManager;
import org.bukkit.plugin.java.JavaPlugin;

public class WheatTycoon extends JavaPlugin {

    private static WheatTycoon instance;
    private TycoonManager tycoonManager;

    @Override
    public void onEnable() {
        if (!VaultUtil.setup()) {
    getLogger().severe("Vault tidak ditemukan!");
    getServer().getPluginManager().disablePlugin(this);
    return;
}

getServer().getPluginManager().registerEvents(
        new TycoonGUIListener(this), this
);
        instance = this;

        // load config
        saveDefaultConfig();

        // init manager
        tycoonManager = new TycoonManager(this);
        tycoonManager.startGenerator();

        // register listeners (STEP 2)
        getServer().getPluginManager().registerEvents(
                new TycoonPlaceListener(this), this
        );
        getServer().getPluginManager().registerEvents(
                new TycoonInteractListener(this), this
        );

        getLogger().info("WheatTycoon STEP 2 enabled");
    }

    @Override
    public void onDisable() {
        getLogger().info("WheatTycoon disabled");
    }

    public static WheatTycoon getInstance() {
        return instance;
    }

    public TycoonManager getTycoonManager() {
        return tycoonManager;
    }
}
