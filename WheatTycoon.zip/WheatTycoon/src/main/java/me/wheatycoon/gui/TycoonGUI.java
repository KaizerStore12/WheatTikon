package me.wheatycoon.gui;

import me.wheatycoon.tycoon.Tycoon;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.List;

public class TycoonGUI {

    public static void open(Player p, Tycoon tycoon) {
        Inventory inv = Bukkit.createInventory(null, 27, "§eWheat Tycoon");

        inv.setItem(11, button(Material.WHEAT,
                "§aCollect Wheat",
                "§7Stored: §e" + tycoon.getStoredWheat()));

        inv.setItem(13, button(Material.GOLD_INGOT,
                "§6Auto-Sell Wheat",
                "§7Jual langsung jadi uang"));

        inv.setItem(15, button(Material.ANVIL,
                "§bUpgrade Tycoon",
                "§7Level: §e" + tycoon.getLevel()));

        p.openInventory(inv);
    }

    private static ItemStack button(Material m, String name, String lore) {
        ItemStack item = new ItemStack(m);
        ItemMeta meta = item.getItemMeta();
        meta.setDisplayName(name);
        meta.setLore(List.of(lore));
        item.setItemMeta(meta);
        return item;
    }
}
